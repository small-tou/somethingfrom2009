define(function(require, exports, module) {
    var GO=function(){

    }
    GO.prototype={
        init:function(context){
            // this.x=0;
            //  this.y=0;
            //   this.width=0;
            //   this.height=0;
            this.rotation=0;
            this.can_scale=1;
            this.can_resize=0;
            this.controlPoints=[]
            this.context=context
            this.scale=context.scale
            this._init();
        },
        _init:function(){

        }
    }
    return GO;
});

