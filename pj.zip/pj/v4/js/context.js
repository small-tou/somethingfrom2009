(function(){
    var Context=function(){
        init:function(){
            this
        }
    }

    SCD.Context=Context;
})();

