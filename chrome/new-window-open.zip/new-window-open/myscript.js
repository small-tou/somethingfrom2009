(function(){
    var as=document.getElementsByTagName("a");
    for(var i =0;i<as.length;i++){
        as[i].setAttribute("target", "_blank")
    }
})();