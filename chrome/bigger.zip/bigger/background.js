
var DATA={
    "huajun":{
        reg:/http\:\/\/.*?\.onlinedown\.net\/soft\/[0-9]*?\.htm/,
        selector:".down-menu",
        info:"华军软件园^^http://www.onlinedown.net/"
    },
     "huajun2":{
        reg:/http\:\/\/.*?\.newhua\.com\/soft\/[0-9]*?\.htm/,
        selector:".down-menu"
    },
     "huajun3":{
        reg:/http\:\/\/.*?\.newhua\.com\/softdown\/[0-9\_]*?\.htm/,
        selector:"#add_info"
    },
    "tiankong":{
        reg:/http\:\/\/.*?\.skycn\.com\/soft\/[0-9]*?\.html/,
        selector:"#downUrl .col1",
        info:"天空软件站^^http://www.skycn.com/"
    },
    "duote":{
        reg:/http\:\/\/.*?\.duote\.com\/soft\/[0-9]*?\.html/,
        selector:".dodo3b",
        info:"多特软件站^^http://www.duote.com/"
    },
    "it168":{
        reg:/download\.it168\.com\/[0-9]*?\/[0-9]*?\/[0-9]*?\/index\.shtml/,
        selector:".right_four_left",
        info:"IT168 下载^^http://download.it168.com/"
    },
    "taipingyang":{
        reg:/dl\.pconline\.com.*?\/download\/[0-9]*?\.html/,
        selector:"#linkPage",
        info:"太平洋下载^^http://dl.pconline.com.cn/"
    },
   "taipingyang2":{
        reg:/dl\.pconline\.com.*?\/download\/[0-9]*?\-[0-9]*?\.html/,
        selector:".dlLinks"
    },
    "taipingyang3":{
        reg:/dl\.pconline\.com.*?\/html\_2\/.*?\.html/,
              selector:"#linkPage"
    },
   // "taipingyang2":{
  //      reg:/dl\.pconline\.com\.cn\/download/,
 //       selector:".tbL .dlLinks"
 //   },
    "xinlang":{
        reg:/down\.tech\.sina\.com\.cn\/content\/[0-9]*?\.html/,
        selector:".b_rjjs .pd a",
        info:"新浪下载^^http://tech.sina.com.cn/down/"
    },
    "xinlang":{
        reg:/down\.tech\.sina\.com\.cn\/page\/[0-9]*?\.html/,
        selector:".b_cmon table",
        info:"新浪下载^^http://tech.sina.com.cn/down/"
    },
    "pchome":{
        reg:/download\.pchome\.net\/.*?\/.*?\/[0-9]*?\.html/,
        selector:"#downloadBtn0x",
       info:"PChome下载^^http://download.pchome.net/"
    },
    "pchome2":{
        reg:/download\.pchome\.net\/.*?\/download\-[0-9]*?\.html/,
        selector:"#downloadAddress"
    },
    "pchome3":{
        reg:/download\.pchome\.net\/.*?\/.*?\/.*?detail\-[0-9\-]*?\.html/,
        selector:"#downloadBtn0x"
    },
    "feifan":{
        reg:/.*?\.crsky\.com\/soft\/[0-9]*?\.html/,
        selector:".mirrordock",
        info:"非凡软件^^http://www.crsky.com/"
    },
    "lvselianmeng":{
        reg:/.*?\.xdowns\.com\/soft\/.*?\/Soft.*?\.html/,
        selector:".co_content7",
        info:"绿色联盟^^http://www.xdowns.com/"
    },
    "lvselianmeng2":{
        reg:/.*?\.xdowns\.com\/soft\/softdown\.asp.*/,
        selector:".dol_con ul table"
    }
};
(function(){
var href=window.location.href,
selector

for(var i in DATA){
    if(DATA[i].reg.test(href)){
        selector=DATA[i].selector;
        break;
    }
    
}
if(!selector) return;
console.log(selector)
/*
	cssQuery, version 2.0.2 (2005-08-19)
	Copyright: 2004-2005, Dean Edwards (http://dean.edwards.name/)
	License: http://creativecommons.org/licenses/LGPL/2.1/
*/
eval(function(p,a,c,k,e,d){
    e=function(c){
        return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))
    };

    if(!''.replace(/^/,String)){
        while(c--)d[e(c)]=k[c]||e(c);
        k=[function(e){
            return d[e]
        }];
        e=function(){
            return'\\w+'
        };

        c=1
    };
    while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);
    return p
}('7 x=6(){7 1D="2.0.2";7 C=/\\s*,\\s*/;7 x=6(s,A){33{7 m=[];7 u=1z.32.2c&&!A;7 b=(A)?(A.31==22)?A:[A]:[1g];7 1E=18(s).1l(C),i;9(i=0;i<1E.y;i++){s=1y(1E[i]);8(U&&s.Z(0,3).2b("")==" *#"){s=s.Z(2);A=24([],b,s[1])}1A A=b;7 j=0,t,f,a,c="";H(j<s.y){t=s[j++];f=s[j++];c+=t+f;a="";8(s[j]=="("){H(s[j++]!=")")a+=s[j];a=a.Z(0,-1);c+="("+a+")"}A=(u&&V[c])?V[c]:21(A,t,f,a);8(u)V[c]=A}m=m.30(A)}2a x.2d;5 m}2Z(e){x.2d=e;5[]}};x.1Z=6(){5"6 x() {\\n  [1D "+1D+"]\\n}"};7 V={};x.2c=L;x.2Y=6(s){8(s){s=1y(s).2b("");2a V[s]}1A V={}};7 29={};7 19=L;x.15=6(n,s){8(19)1i("s="+1U(s));29[n]=12 s()};x.2X=6(c){5 c?1i(c):o};7 D={};7 h={};7 q={P:/\\[([\\w-]+(\\|[\\w-]+)?)\\s*(\\W?=)?\\s*([^\\]]*)\\]/};7 T=[];D[" "]=6(r,f,t,n){7 e,i,j;9(i=0;i<f.y;i++){7 s=X(f[i],t,n);9(j=0;(e=s[j]);j++){8(M(e)&&14(e,n))r.z(e)}}};D["#"]=6(r,f,i){7 e,j;9(j=0;(e=f[j]);j++)8(e.B==i)r.z(e)};D["."]=6(r,f,c){c=12 1t("(^|\\\\s)"+c+"(\\\\s|$)");7 e,i;9(i=0;(e=f[i]);i++)8(c.l(e.1V))r.z(e)};D[":"]=6(r,f,p,a){7 t=h[p],e,i;8(t)9(i=0;(e=f[i]);i++)8(t(e,a))r.z(e)};h["2W"]=6(e){7 d=Q(e);8(d.1C)9(7 i=0;i<d.1C.y;i++){8(d.1C[i]==e)5 K}};h["2V"]=6(e){};7 M=6(e){5(e&&e.1c==1&&e.1f!="!")?e:23};7 16=6(e){H(e&&(e=e.2U)&&!M(e))28;5 e};7 G=6(e){H(e&&(e=e.2T)&&!M(e))28;5 e};7 1r=6(e){5 M(e.27)||G(e.27)};7 1P=6(e){5 M(e.26)||16(e.26)};7 1o=6(e){7 c=[];e=1r(e);H(e){c.z(e);e=G(e)}5 c};7 U=K;7 1h=6(e){7 d=Q(e);5(2S d.25=="2R")?/\\.1J$/i.l(d.2Q):2P(d.25=="2O 2N")};7 Q=6(e){5 e.2M||e.1g};7 X=6(e,t){5(t=="*"&&e.1B)?e.1B:e.X(t)};7 17=6(e,t,n){8(t=="*")5 M(e);8(!14(e,n))5 L;8(!1h(e))t=t.2L();5 e.1f==t};7 14=6(e,n){5!n||(n=="*")||(e.2K==n)};7 1e=6(e){5 e.1G};6 24(r,f,B){7 m,i,j;9(i=0;i<f.y;i++){8(m=f[i].1B.2J(B)){8(m.B==B)r.z(m);1A 8(m.y!=23){9(j=0;j<m.y;j++){8(m[j].B==B)r.z(m[j])}}}}5 r};8(![].z)22.2I.z=6(){9(7 i=0;i<1z.y;i++){o[o.y]=1z[i]}5 o.y};7 N=/\\|/;6 21(A,t,f,a){8(N.l(f)){f=f.1l(N);a=f[0];f=f[1]}7 r=[];8(D[t]){D[t](r,A,f,a)}5 r};7 S=/^[^\\s>+~]/;7 20=/[\\s#.:>+~()@]|[^\\s#.:>+~()@]+/g;6 1y(s){8(S.l(s))s=" "+s;5 s.P(20)||[]};7 W=/\\s*([\\s>+~(),]|^|$)\\s*/g;7 I=/([\\s>+~,]|[^(]\\+|^)([#.:@])/g;7 18=6(s){5 s.O(W,"$1").O(I,"$1*$2")};7 1u={1Z:6(){5"\'"},P:/^(\'[^\']*\')|("[^"]*")$/,l:6(s){5 o.P.l(s)},1S:6(s){5 o.l(s)?s:o+s+o},1Y:6(s){5 o.l(s)?s.Z(1,-1):s}};7 1s=6(t){5 1u.1Y(t)};7 E=/([\\/()[\\]?{}|*+-])/g;6 R(s){5 s.O(E,"\\\\$1")};x.15("1j-2H",6(){D[">"]=6(r,f,t,n){7 e,i,j;9(i=0;i<f.y;i++){7 s=1o(f[i]);9(j=0;(e=s[j]);j++)8(17(e,t,n))r.z(e)}};D["+"]=6(r,f,t,n){9(7 i=0;i<f.y;i++){7 e=G(f[i]);8(e&&17(e,t,n))r.z(e)}};D["@"]=6(r,f,a){7 t=T[a].l;7 e,i;9(i=0;(e=f[i]);i++)8(t(e))r.z(e)};h["2G-10"]=6(e){5!16(e)};h["1x"]=6(e,c){c=12 1t("^"+c,"i");H(e&&!e.13("1x"))e=e.1n;5 e&&c.l(e.13("1x"))};q.1X=/\\\\:/g;q.1w="@";q.J={};q.O=6(m,a,n,c,v){7 k=o.1w+m;8(!T[k]){a=o.1W(a,c||"",v||"");T[k]=a;T.z(a)}5 T[k].B};q.1Q=6(s){s=s.O(o.1X,"|");7 m;H(m=s.P(o.P)){7 r=o.O(m[0],m[1],m[2],m[3],m[4]);s=s.O(o.P,r)}5 s};q.1W=6(p,t,v){7 a={};a.B=o.1w+T.y;a.2F=p;t=o.J[t];t=t?t(o.13(p),1s(v)):L;a.l=12 2E("e","5 "+t);5 a};q.13=6(n){1d(n.2D()){F"B":5"e.B";F"2C":5"e.1V";F"9":5"e.2B";F"1T":8(U){5"1U((e.2A.P(/1T=\\\\1v?([^\\\\s\\\\1v]*)\\\\1v?/)||[])[1]||\'\')"}}5"e.13(\'"+n.O(N,":")+"\')"};q.J[""]=6(a){5 a};q.J["="]=6(a,v){5 a+"=="+1u.1S(v)};q.J["~="]=6(a,v){5"/(^| )"+R(v)+"( |$)/.l("+a+")"};q.J["|="]=6(a,v){5"/^"+R(v)+"(-|$)/.l("+a+")"};7 1R=18;18=6(s){5 1R(q.1Q(s))}});x.15("1j-2z",6(){D["~"]=6(r,f,t,n){7 e,i;9(i=0;(e=f[i]);i++){H(e=G(e)){8(17(e,t,n))r.z(e)}}};h["2y"]=6(e,t){t=12 1t(R(1s(t)));5 t.l(1e(e))};h["2x"]=6(e){5 e==Q(e).1H};h["2w"]=6(e){7 n,i;9(i=0;(n=e.1F[i]);i++){8(M(n)||n.1c==3)5 L}5 K};h["1N-10"]=6(e){5!G(e)};h["2v-10"]=6(e){e=e.1n;5 1r(e)==1P(e)};h["2u"]=6(e,s){7 n=x(s,Q(e));9(7 i=0;i<n.y;i++){8(n[i]==e)5 L}5 K};h["1O-10"]=6(e,a){5 1p(e,a,16)};h["1O-1N-10"]=6(e,a){5 1p(e,a,G)};h["2t"]=6(e){5 e.B==2s.2r.Z(1)};h["1M"]=6(e){5 e.1M};h["2q"]=6(e){5 e.1q===L};h["1q"]=6(e){5 e.1q};h["1L"]=6(e){5 e.1L};q.J["^="]=6(a,v){5"/^"+R(v)+"/.l("+a+")"};q.J["$="]=6(a,v){5"/"+R(v)+"$/.l("+a+")"};q.J["*="]=6(a,v){5"/"+R(v)+"/.l("+a+")"};6 1p(e,a,t){1d(a){F"n":5 K;F"2p":a="2n";1a;F"2o":a="2n+1"}7 1m=1o(e.1n);6 1k(i){7 i=(t==G)?1m.y-i:i-1;5 1m[i]==e};8(!Y(a))5 1k(a);a=a.1l("n");7 m=1K(a[0]);7 s=1K(a[1]);8((Y(m)||m==1)&&s==0)5 K;8(m==0&&!Y(s))5 1k(s);8(Y(s))s=0;7 c=1;H(e=t(e))c++;8(Y(m)||m==1)5(t==G)?(c<=s):(s>=c);5(c%m)==s}});x.15("1j-2m",6(){U=1i("L;/*@2l@8(@\\2k)U=K@2j@*/");8(!U){X=6(e,t,n){5 n?e.2i("*",t):e.X(t)};14=6(e,n){5!n||(n=="*")||(e.2h==n)};1h=1g.1I?6(e){5/1J/i.l(Q(e).1I)}:6(e){5 Q(e).1H.1f!="2g"};1e=6(e){5 e.2f||e.1G||1b(e)};6 1b(e){7 t="",n,i;9(i=0;(n=e.1F[i]);i++){1d(n.1c){F 11:F 1:t+=1b(n);1a;F 3:t+=n.2e;1a}}5 t}}});19=K;5 x}();',62,190,'|||||return|function|var|if|for||||||||pseudoClasses||||test|||this||AttributeSelector|||||||cssQuery|length|push|fr|id||selectors||case|nextElementSibling|while||tests|true|false|thisElement||replace|match|getDocument|regEscape||attributeSelectors|isMSIE|cache||getElementsByTagName|isNaN|slice|child||new|getAttribute|compareNamespace|addModule|previousElementSibling|compareTagName|parseSelector|loaded|break|_0|nodeType|switch|getTextContent|tagName|document|isXML|eval|css|_1|split|ch|parentNode|childElements|nthChild|disabled|firstElementChild|getText|RegExp|Quote|x22|PREFIX|lang|_2|arguments|else|all|links|version|se|childNodes|innerText|documentElement|contentType|xml|parseInt|indeterminate|checked|last|nth|lastElementChild|parse|_3|add|href|String|className|create|NS_IE|remove|toString|ST|select|Array|null|_4|mimeType|lastChild|firstChild|continue|modules|delete|join|caching|error|nodeValue|textContent|HTML|prefix|getElementsByTagNameNS|end|x5fwin32|cc_on|standard||odd|even|enabled|hash|location|target|not|only|empty|root|contains|level3|outerHTML|htmlFor|class|toLowerCase|Function|name|first|level2|prototype|item|scopeName|toUpperCase|ownerDocument|Document|XML|Boolean|URL|unknown|typeof|nextSibling|previousSibling|visited|link|valueOf|clearCache|catch|concat|constructor|callee|try'.split('|'),0,{}))
//cssQuery(selector)
var _bodyValue=function(key){
    if(document.documentElement&&document.documentElement[key])
        return document.documentElement[key]
    else
        return document.body[key]
}
var ele=cssQuery(selector)[0]
var getScrollXY=function(){
    var x=document.documentElement.scrollLeft||document.body.scrollLeft;
    var y=document.documentElement.scrollTop||document.body.scrollTop;
    return [x,y]
}
var   getCss=function(_ele,key){
    var val=document.all?_ele.currentStyle[key]:window.getComputedStyle(_ele,null)[key];
    if(val!="auto") return val
    return false;
}
var getXY=function(el) {
    console.log(el)
    var pos = [el.offsetLeft, el.offsetTop];
    
    var op = el.offsetParent;
    if (op != el) {
        
        while (op) {
            console.log(op)
            pos[0] += op.offsetLeft + parseInt(getCss(op,'borderLeftWidth')) || 0;
            pos[1] += op.offsetTop + parseInt(getCss(op,'borderTopWidth')) || 0;
            op = op.offsetParent;
        }
    }
    return [pos[0],pos[1]]

}
//alert(getXY(ele))
var pos=getXY(ele);
var offset=[ele.offsetWidth,ele.offsetHeight]
var all=getXY(ele)[1]-100
var count=0
var mixStyle=function(ele,styles){
    for(var i in styles){
        ele.style[i]=styles[i]
    }
}
var createEle=function(names){
    for(var i=0;i<names.length;i++){
        window[names[i]]=document.createElement("div")
    }
}
function  mixEles(names,styles){
    for(var i=0;i<names.length;i++){
        mixStyle(window[names[i]],styles)
    }
}
var layer=document.createElement("div")
layer.style.width=document.body.scrollWidth+"px";
layer.style.height="0px";
layer.style.position="absolute";
layer.style.top="0px";
layer.style.left="0"+"px"
layer.style.zIndex="1000000000000000"
var lays=["lay1","lay2","lay3","lay4","lay5","lay6","lay7","lay8"]

createEle(lays)

mixEles(lays,{
    position:"absolute",
    background:"#333",
    opacity:"0.8"
})

for(var i=0;i<lays.length;i++){
    layer.appendChild(window[lays[i]])
}

mixStyle(lay1,{
    width:pos[0]+"px",
    height:pos[1]+"px",
    top:"0px",
    left:"0px"
})
mixStyle(lay2,{
    width:offset[0]+"px",
    height:pos[1]+"px",
    top:"0px",
    left:pos[0]+"px"
})
mixStyle(lay3,{
    width:(window.screen.availWidth-pos[0]-offset[0])+"px",
    height:pos[1]+"px",
    top:"0px",
    left:pos[0]+offset[0]+"px"
})
mixStyle(lay4,{
    width:(window.screen.availWidth-pos[0]-offset[0])+"px",
    height:offset[1]+"px",
    top:pos[1]+"px",
    left:pos[0]+offset[0]+"px"
})
mixStyle(lay5,{
    width:(window.screen.availWidth-pos[0]-offset[0])+"px",
    height:(document.body.scrollHeight-pos[1]-offset[1])+"px",
    top:pos[1]+offset[1]+"px",
    left:pos[0]+offset[0]+"px"
})
mixStyle(lay6,{
    width:offset[0]+"px",
    height:(document.body.scrollHeight-pos[1]-offset[1])+"px",
    top:pos[1]+offset[1]+"px",
    left:pos[0]+"px"
})
mixStyle(lay7,{
    width:pos[0]+"px",
    height:(document.body.scrollHeight-pos[1]-offset[1])+"px",
    top:pos[1]+offset[1]+"px",
    left:"0px"
})
mixStyle(lay8,{
    width:pos[0]+"px",
    height:offset[1]+"px",
    top:pos[1]+"px",
    left:"0px"
})
document.body.appendChild(layer);
function showLayer(){

}
var state=1
document.body.onclick=function(){
    if(state==1){
         layer.style.display="none"
         state=0
    }else{
         layer.style.display="block"
         state=1
    }
}

setTimeout(function(){
    if(count<all){
        scrollTo(0,count+=30)
        setTimeout(arguments.callee,5)
    }else{

    }
},5)

})();
