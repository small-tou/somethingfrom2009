<html xmlns="http://www.w3.org/1999/xhtml"><head>
			        	<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
        	<title>淘宝网 - 淘我喜欢！</title>
        	<meta http-equiv="X-UA-Compatible" content="IE=7">
        	<meta name="description" content="欢迎免费注册淘宝，淘宝 - 亚洲最大的网上交易平台，拥有近2亿商品，提供安全便捷的购物体验，提供先行赔付、假一赔三、7天无理由退货等售后服务，同时这里还提供了各类网上赚钱的机会。">
        	<meta name="keywords" content="会员注册 免费 淘宝 网上开店 网上购物 网上交易 网上商店 免费开店 网上买东西">
        	<link rel="shortcut icon" href="http://www.daily.taobao.net/images/favicon.ico" type="image/x-icon">
        	<link rel="search" type="application/opensearchdescription+xml" href="http://assets.taobaocdn.com/plugins/opensearch/provider.xml" title="淘宝购物">

        	<link rel="stylesheet" href="http://assets.taobaocdn.com/app/uc/register.css?t=200905011.css">

        	<link href="http://assets.taobaocdn.com/css/chl/itaobao/itaobao.css?t=20080927.css" rel="stylesheet">
        	<link href="http://assets.taobaocdn.com/app/uc/register.css?t=200905011.css" rel="stylesheet">
    			<!--
	千城注册埋点js， 用户离开邮箱注册激活成功后请求服务器，统计在注册成功页面停留的时间

	去掉埋点后请把body元素里的 onBeforeUnload="javascript:whenExit()" 也一起去掉
			-->
	<script language="javascript">
		var img = new Image();
		function whenExit(){
			img.src = "http://"+(window.location.host)+"/member/tempMaiDian.do?from=email&times=" + (new Date()).getTime()+"&timearg=1293180735378";
		}

    </script>
<script src="http://a.tbcdn.cn/app/search/monitor.js?t=20100331.js"></script><link id="yui__dyn_0" type="text/css" charset="utf-8" rel="stylesheet" href="http://assets.daily.taobao.net/tbra/1.0/assets/tbra.css?t=201003241751.css"></head>
<body class="chl-reg" onbeforeunload="javascript:whenExit()">
	<div id="page">
					    			<!-- from vmcommon -->
    <link rel="stylesheet" href="http://assets.daily.taobao.net/p/header/header-min.css?t=20100610.css">
    <script src="http://assets.daily.taobao.net/p/header/header-v7-min.js?t=20100701.js"></script>
          		<link rel="stylesheet" href="http://assets.daily.taobao.net/tbsp/tbsp.css?t=20090602.css">
	    		<script src="http://assets.daily.taobao.net/tbra/1.0/tbra-widgets.js?t=201003241751.js"></script>



<!-- end vmcommon -->





    			        			<!-- from vmcommon header_register-->
<link rel="stylesheet" href="http://assets.daily.taobao.net/p/mall/base/header.source.css?t=20100701.css">
<link rel="stylesheet" href="http://assets.daily.taobao.net/p/mall/2.0/css/tmall_reg.css?t=20101221.css">

<div id="header" class="tmall_reg">
         <div id="site-nav">


            <p class="login-info">
              <script>
(function(y){y=y||{};var q={getCookie:function(a){var b=document.cookie.match("(?:^|;)\\s*"+a+"=([^;]*)");return(b&&b[1])?decodeURIComponent(b[1]):""},escapeHTML:function(b){var a=document.createElement("div"),c=document.createTextNode(b);a.appendChild(c);return a.innerHTML}};var E=(window.location.hostname.indexOf("daily")!=-1);var C=q.getCookie("_nk_"),r=(q.getCookie("login")=="true"),w=new Date().getTime(),x=y.memberServer||"http://member1.taobao.com",A=y.loginServer||x,t="http://login.tmall.com";var B=location.href;if(/^http.*(\/member\/login\.jhtml)$/i.test(B)){B=""}var D=y.redirectUrl||B;if(D){t+="?redirect_url="+encodeURIComponent(D)}var u="https://login.taobao.com/member/logout.jhtml?f=top&redirectURL=http://login.tmall.com/%3Fredirect_url%3D"+encodeURIComponent(D.replace(/\&/g,"_*and*_"));var v=x+"/member/newbie.htm";var s=x+"/message/list_private_msg.htm?t="+w;var p="http://jianghu.taobao.com/admin/home.htm?t="+w;if(E){u="https://login.daily.taobao.net/member/logout.jhtml?f=top&redirectURL=http://login.tmall.com/%3FisDaily=1%26redirect_url%3D"+encodeURIComponent(D.replace(/\&/g,"_*and*_"));t+="&isDaily=1"}var z="";if((window.location.href.indexOf("taobao.com")!=-1)||(window.location.href.indexOf("taobao.net")!=-1)){if(C){z='\u60a8\u597d\uff0c<a class="user-nick" href="'+p+'" target="_top">'+q.escapeHTML(unescape(C.replace(/\\u/g,"%u")))+'</a>\uff01<a id="J_Logout" href="'+u+'" target="_top">\u9000\u51fa</a><a href="'+s+'" target="_top">\u7ad9\u5185\u4fe1';z+="</a>"}else{z='\u60a8\u597d\uff0c\u6b22\u8fce\u6765\u6dd8\u5b9d\uff01<a href="'+t+'" target="_top">\u8bf7\u767b\u5f55</a>';z+='<a href="'+v+'" target="_top">\u514d\u8d39\u6ce8\u518c</a>'}}else{if(r){z='\u60a8\u597d\uff0c<a class="user-nick" href="'+p+'" target="_top">'+q.escapeHTML(unescape(C.replace(/\\u/g,"%u")))+'</a>\uff01<a id="J_Logout" href="'+u+'" target="_top">\u9000\u51fa</a><a href="'+s+'" target="_top">\u7ad9\u5185\u4fe1';z+="</a>"}else{z='\u60a8\u597d\uff0c\u6b22\u8fce\u6765\u6dd8\u5b9d\uff01<a href="'+t+'" target="_top">\u8bf7\u767b\u5f55</a>';z+='<a href="'+v+'" target="_top">\u514d\u8d39\u6ce8\u518c</a>'}}document.write(z)})({memberServer:"http://member1.taobao.com",loginServer:"https://login.taobao.com",redirectUrl:"",logoutUrl:""});

</script>您好，<a class="user-nick" href="http://jianghu.daily.taobao.net/admin/home.htm?t=1293180733843" target="_top">fsdfsd4</a>！<a id="J_Logout" href="https://login.daily.taobao.net/member/logout.jhtml?f=top&amp;redirectURL=http://login.tmall.com/%3FisDaily=1%26redirect_url%3Dhttp%3A%2F%2Fmember1.daily.taobao.net%2Fmember%2Fregister_confirm.jhtml%3Fu%3D93bb817cc636052a1bd9ad99a64b0ee8_*and*_a%3D2oYpeVSN_*and*_i%3Dnull_*and*_y%3Dnull_*and*_r%3Dnull_*and*_src%3Dnull_*and*_st%3Dnull_*and*_tu%3Dnull_*and*_rdn%3Dnull_*and*_css_style%3Dtmall" target="_top">退出</a><a href="http://member1.daily.taobao.net/message/list_private_msg.htm?t=1293180733843" target="_top">站内信</a>
      </p>
                <ul class="quick-menu">
            <li class="home"><a href="http://www.daily.taobao.net/" target="_top">淘宝网首页</a></li>


        </ul>
</div>


   <div class="layout">
        <div class="layout-inner">
             <h1 id="mall-logo" class="clearfix">
                 <span class="mlogo"><a href="http://www.tmall.com/" title="淘宝商城" target="_top"><img alt="淘宝商城" src="http://img02.taobaocdn.com/tps/i2/T1HN8UXXFxXXXXXXXX-125-45.png" width="125" height="45"></a></span>
                 <span class="slogo"><a href="http://member1.daily.taobao.net/member/register_confirm.jhtml?u=93bb817cc636052a1bd9ad99a64b0ee8&amp;a=2oYpeVSN&amp;i=null&amp;y=null&amp;r=null&amp;src=null&amp;st=null&amp;tu=null&amp;rdn=null&amp;css_style=tmall#" target="_top">注册</a></span>
              </h1>
          </div>
    </div>
</div>
<script>(function(){
                var d=document,h=d.getElementById("head"),as=d.getElementsByTagName("a"),fs=d.getElementsByTagName("form")
                for(var i =0;i<as.length;i++){
                    as[i].setAttribute("target", "_top")
                }
                for(var i =0;i<fs.length;i++){
                    fs[i].setAttribute("target", "_top")
                }
            })();</script>
<script>TB.Header.init();</script>
<!-- end vmcommon x -->


	    <!--Hitao END-->
	<div id="content"><!-- 页面content内容开始 -->

        	<div class="flow-steps" style="width:990px; margin: 20px auto;">
        		<ol class="num3">
    				<li class="done"><span class="first">1. 填写会员信息</span></li>
        			<li class="done current-prev"><span>2. 通过邮件确认</span></li>
        			<li class="last current"><strong>3. 注册成功</strong></li>
        		</ol>
        	</div>

        	<div class="msg24" style="width:990px; margin:0 auto;">
        		<script src="http://assets.taobaocdn.com/sys/wangwang/website.js?t=20090319.js"></script>
        			<p class="ok">
        				        					恭喜，注册成功！<br>
							<!--
            											-->
            				<span class="success-info">您的淘宝账户名为<strong>fsdfsd4</strong>，
            				该账号可同时用于<a id="ww-download" href="http://www.taobao.com/wangwang/" target="_blank"><img src="http://im.alisoft.com/images/icon/01.gif" align="absmiddle">阿里旺旺</a>登录。
            				            				<br>支付宝账户名为<strong>elexonnu_321@yopmail.com</strong>，登录密码 <strong>同淘宝登录密码</strong></span>
            				<span class="skin-blue"><a class="long-btn" href="http://life.alipay.com/activity/zjqd/tb/qdtaobao.html?src=yy_taobaojihuo_091030" title="查看支付方式"><font color="#ffffff">查看支付方式</font></a></span>
        					                                			</p>
    			<script type="text/javascript">
        				(function(){
        					if(checkIMVersionNoMsg('cntaobao')<0){
        						var ww = document.getElementById("ww-download");
        						ww.setAttribute("href","http://www.taobao.com/wangwang/");
        						ww.setAttribute("target","_blank");
        					}
        				})();
        		</script>
    		</div>



		    </div>


        		        			<div id="footer">
    <div id="mall-desc">
        <dl id="ensure">
            <dt><span>商城保障</span></dt>
            <dd>
                <a href="javascript:;"><i></i>7天无理由退换货</a>
                <a href="javascript:;"><i></i>100%正品保障</a>
                <a href="javascript:;"><i></i>提供发票</a>
            </dd>
        </dl>
        <dl id="beginner">
            <dt><span>新手上路</span></dt>
            <dd>
                <a href="http://member1.taobao.com/member/register.jhtml?_lang=default" target="_blank"><i></i>免费注册</a>
                <a href="https://www.alipay.com/user/reg_select.htm" target="_blank"><i></i>开通支付宝</a>
                <a href="http://trust.taobao.com/" target="_blank"><i></i>安全购物指南</a>
                <a href="http://support.taobao.com/myservice/rights/right_main.htm" target="_blank"><i></i>消费者维权中心</a>
            </dd>
        </dl>

        <dl id="payment">
            <dt><span>支付方式</span></dt>
            <dd>
                <a href="http://www.taobao.com/wui/pay/index.php?f=katong&amp;p=index#s1-1-1"><i></i>支付宝卡通付款</a>
                <a href="http://www.taobao.com/wui/pay/index.php?f=credit&amp;p=cmb#s1-1-1"><i></i>信用卡支付</a>
                <a href="http://www.taobao.com/go/act/sale/syzxfw_090602_qcz.php?TBG=14172.64.10"><i></i>货到付款</a>
                <a href="http://www.taobao.com/wui/pay/index.php?f=bankcard&amp;p=cmb#s1-1-1"><i></i>网上银行支付</a>
            </dd>
        </dl>

        <dl id="seller">
            <dt><span>商家入住</span></dt>
            <dd>
                <a href="http://zhaoshang.tmall.com/" target="_blank" class="join"><i></i>立即加入 &gt;&gt;</a>
                <a href="http://www.tmall.com/go/chn/mall/zhaoshang_produce.php" target="_blank"><i></i>了解商城</a>
                <a href="http://www.tmall.com/go/chn/mall/zhaoshang_flow.php" target="_blank"><i></i>申请流程</a>
                <a href="http://bbs.taobao.com/catalog/443501.htm" target="_blank"><i></i>商家社区</a>
            </dd>
        </dl>
        <!--[if IE 6]> <br /> <![endif]-->
        <h4 class="go-home"><a href="http://www.tmall.com" target="_blank" title="返回淘宝商城首页">返回淘宝商城首页</a></h4>
    </div>
    <div id="copyright">

    </div>
        <div class="server-num">chonglou-PC</div>
</div>


        									<script type="text/javascript" src="http://assets.taobaocdn.com/js/chl/itaobao/itaobao-base.js?t=20080927.js"></script>
	</div>

</body></html>