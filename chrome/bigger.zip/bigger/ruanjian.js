/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
var data={
    "QQ":"http://www.skycn.com/soft/4934.html",
    "迅雷":"http://www.skycn.com/soft/14857.html",
    "搜狗拼音":"http://www.skycn.com/soft/27159.html"
}

