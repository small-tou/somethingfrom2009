chrome.extension.sendRequest({cmd: "update"}, function(response) {
 console.log(response)
});
